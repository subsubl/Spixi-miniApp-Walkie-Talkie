// Spixi Mini Apps SDK

var SpixiAppSdk = {
    version: 0.4,
    date: "2025-08-01",
    _isTestEnv: window.location.protocol !== "file:",

    fireOnLoad: function () {
        if (this._isTestEnv) {
            console.log("SpixiAppSdk [Test Mode]: Fired onLoad. Triggering onInit.");
            // In a test environment, we need to manually trigger onInit
            // to start the app, as there is no native host.
            setTimeout(() => {
                this.onInit("test-session-id", ["test-user-address-1", "test-user-address-2"]);
            }, 100);
        } else {
            location.href = "ixian:onload";
        }
    },

    back: function () {
        if (this._isTestEnv) {
            console.log("SpixiAppSdk [Test Mode]: back() called.");
        } else {
            location.href = "ixian:back";
        }
    },

    sendNetworkData: function (data) {
        if (this._isTestEnv) {
            console.log("SpixiAppSdk [Test Mode]: sendNetworkData called. Looping back.");
            // Loop back the data to simulate receiving it from a peer
            setTimeout(() => {
                this.onNetworkData("test-peer-address", data);
            }, 50); // small delay to simulate network
        } else {
            location.href = "ixian:data" + encodeURIComponent(data);
        }
    },

    sendNetworkProtocolData: function (protocolId, data) {
         if (this._isTestEnv) {
            console.log(`SpixiAppSdk [Test Mode]: sendNetworkProtocolData (${protocolId}) called. Looping back.`);
            // Loop back the data to simulate receiving it from a peer
            setTimeout(() => {
                this.onNetworkProtocolData("test-peer-address", protocolId, data);
            }, 50);
        } else {
            location.href = "ixian:protocolData" + protocolId + "=" + encodeURIComponent(data);
        }
    },

    getStorageData: function (key) {
        if (this._isTestEnv) {
             console.log(`SpixiAppSdk [Test Mode]: getStorageData for key '${key}'. Returning null.`);
             setTimeout(() => this.onStorageData(key, null), 0);
        } else {
            location.href = "ixian:getStorageData" + encodeURIComponent(key);
        }
    },

    setStorageData: function (key, value) {
        if (this._isTestEnv) {
            console.log(`SpixiAppSdk [Test Mode]: setStorageData for key '${key}'.`);
        } else {
            location.href = "ixian:setStorageData" + encodeURIComponent(key) + "=" + encodeURIComponent(value);
        }
    },

    spixiAction: function (actionData) {
        if (this._isTestEnv) {
            console.log("SpixiAppSdk [Test Mode]: spixiAction called with:", actionData);
        } else {
            location.href = "ixian:action" + encodeURIComponent(actionData);
        }
    },

    // on* handlers should be overriden by the app
    onInit: function (sessionId, userAddresses) { console.log("SpixiAppSdk: onInit handler not implemented by app."); },
    onStorageData: function (key, value) { console.log("SpixiAppSdk: onStorageData handler not implemented by app."); },
    onNetworkData: function (senderAddress, data) { console.log("SpixiAppSdk: onNetworkData handler not implemented by app."); },
    onNetworkProtocolData: function (senderAddress, protocolId, data) { console.log("SpixiAppSdk: onNetworkProtocolData handler not implemented by app."); },
    onRequestAccept: function (data) { console.log("SpixiAppSdk: onRequestAccept handler not implemented by app."); },
    onRequestReject: function (data) { console.log("SpixiAppSdk: onRequestReject handler not implemented by app."); },
    onAppEndSession: function (data) { console.log("SpixiAppSdk: onAppEndSession handler not implemented by app."); },
};
