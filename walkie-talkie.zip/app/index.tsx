import React, { useState, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from "@google/genai";

// --- Spixi SDK TypeScript Declarations ---
declare const SpixiAppSdk: any;
declare const SpixiTools: any;

const SPIXI_PROTOCOL_ID = "com.ixilabs.spixi.walkie-talkie";

// --- Helper Functions for Audio Encoding/Decoding ---

function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

function createBlob(data: Float32Array): Blob {
    const l = data.length;
    const int16 = new Int16Array(l);
    for (let i = 0; i < l; i++) {
        int16[i] = data[i] * 32768;
    }
    return {
        data: encode(new Uint8Array(int16.buffer)),
        mimeType: 'audio/pcm;rate=16000',
    };
}


const App = () => {
    const [status, setStatus] = useState('Initializing...');
    const [transcript, setTranscript] = useState<{ from: 'user' | 'peer'; text: string }[]>([]);
    const [isRecording, setIsRecording] = useState(false);
    const isRecordingRef = useRef(isRecording);

    const sessionPromise = useRef<Promise<any> | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const outputAudioContextRef = useRef<AudioContext | null>(null);
    const nextStartTimeRef = useRef(0);
    const transcriptEndRef = useRef<HTMLDivElement>(null);
    
    const currentInputTranscription = useRef('');

    useEffect(() => {
        isRecordingRef.current = isRecording;
    }, [isRecording]);

    useEffect(() => {
        const scrollToBottom = () => {
            transcriptEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        };
        scrollToBottom();
    }, [transcript]);

    useEffect(() => {
        // --- Spixi SDK Handlers ---
        SpixiAppSdk.onNetworkData = (senderAddress: string, data: string) => {
            const outputAudioContext = outputAudioContextRef.current;
            if (!outputAudioContext) return;
            
            (async () => {
                try {
                    const audioBytes = decode(data);
                    // Incoming audio is 16kHz from the microphone
                    const audioBuffer = await decodeAudioData(audioBytes, outputAudioContext, 16000, 1);
                    nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputAudioContext.currentTime);
                    const source = outputAudioContext.createBufferSource();
                    source.buffer = audioBuffer;
                    source.connect(outputAudioContext.destination);
                    source.start(nextStartTimeRef.current);
                    nextStartTimeRef.current += audioBuffer.duration;
                } catch (e) {
                    console.error("Failed to process incoming audio", e);
                }
            })();
        };
        
        SpixiAppSdk.onNetworkProtocolData = (senderAddress: string, protocolId: string, data: string) => {
             if (protocolId === SPIXI_PROTOCOL_ID) {
                const messageText = SpixiTools.unescapeParameter(data);
                setTranscript(prev => [...prev, { from: 'peer', text: messageText.trim() }]);
            }
        };

        async function init() {
            try {
                setStatus('Requesting Permissions...');
                streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
                
                setStatus('Connecting to Gemini...');
                const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

                outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                
                sessionPromise.current = ai.live.connect({
                    model: 'gemini-2.5-flash-native-audio-preview-09-2025',
                    config: {
                        responseModalities: [Modality.AUDIO],
                        speechConfig: {
                            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } },
                        },
                        systemInstruction: "You are a transcription service. Your only job is to transcribe the user's audio accurately.",
                        inputAudioTranscription: {},
                    },
                    callbacks: {
                        onopen: () => {
                            setStatus('Ready');
                            const inputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
                            const source = inputAudioContext.createMediaStreamSource(streamRef.current!);
                            const scriptProcessor = inputAudioContext.createScriptProcessor(4096, 1, 1);

                            scriptProcessor.onaudioprocess = (audioProcessingEvent) => {
                                if (!isRecordingRef.current) return;
                                const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                                const pcmBlob = createBlob(inputData);
                                
                                // Send to Gemini for STT
                                sessionPromise.current?.then((session) => {
                                    session.sendRealtimeInput({ media: pcmBlob });
                                });
                                // Send to peer via Spixi
                                SpixiAppSdk.sendNetworkData(pcmBlob.data);
                            };

                            source.connect(scriptProcessor);
                            scriptProcessor.connect(inputAudioContext.destination);
                        },
                        onmessage: async (message: LiveServerMessage) => {
                            // Only process input transcription from Gemini, ignore any audio/text response
                            if (message.serverContent?.inputTranscription) {
                                currentInputTranscription.current += message.serverContent.inputTranscription.text;
                            }
                            if (message.serverContent?.turnComplete) {
                                if (currentInputTranscription.current) {
                                    const text = currentInputTranscription.current.trim();
                                    setTranscript(prev => [...prev, { from: 'user', text }]);
                                    SpixiAppSdk.sendNetworkProtocolData(SPIXI_PROTOCOL_ID, SpixiTools.escapeParameter(text));
                                    currentInputTranscription.current = '';
                                }
                            }
                        },
                        onerror: (e: ErrorEvent) => {
                            console.error(e);
                            setStatus(`Error: ${e.message}`);
                        },
                        onclose: () => {
                            setStatus('Connection Closed');
                        },
                    },
                });

            } catch (error) {
                console.error('Initialization failed:', error);
                setStatus('Error: Could not initialize. Please check permissions and refresh.');
            }
        }

        init();
        SpixiAppSdk.fireOnLoad();

        return () => {
            streamRef.current?.getTracks().forEach(track => track.stop());
            outputAudioContextRef.current?.close();
            sessionPromise.current?.then(session => session.close());
        };
    }, []);

    const handlePress = () => {
        if (status === 'Ready') {
            setIsRecording(true);
        }
    };

    const handleRelease = () => {
        setIsRecording(false);
    };

    const buttonText = isRecording ? 'Recording...' : 'Push to Talk';
    const isDisabled = status !== 'Ready';

    return (
        <div style={styles.container}>
            <header style={styles.header}>
                <h1 style={styles.title}>Walkie-Talkie</h1>
                <p style={styles.status}>Status: {status}</p>
            </header>
            <main style={styles.transcriptContainer}>
                {transcript.map((entry, index) => (
                    <div key={index} style={{...styles.message, ...(entry.from === 'user' ? styles.userMessage : styles.modelMessage)}}>
                       <strong>{entry.from === 'user' ? 'You:' : 'Peer:'}</strong> {entry.text}
                    </div>
                ))}
                <div ref={transcriptEndRef} />
            </main>
            <footer style={styles.footer}>
                <button
                    style={{...styles.button, ...(isRecording ? styles.buttonActive : {}), ...(isDisabled ? styles.buttonDisabled : {})}}
                    onMouseDown={handlePress}
                    onMouseUp={handleRelease}
                    onTouchStart={handlePress}
                    onTouchEnd={handleRelease}
                    disabled={isDisabled}
                    aria-label={buttonText}
                >
                    <div style={styles.micIcon}>
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" width="48" height="48">
                            <path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"></path>
                            <path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"></path>
                        </svg>
                    </div>
                </button>
            </footer>
        </div>
    );
};

const styles: { [key: string]: React.CSSProperties } = {
    container: {
        display: 'flex',
        flexDirection: 'column',
        height: '100%',
        width: '100%',
        backgroundColor: '#1a1a1a',
    },
    header: {
        padding: '16px',
        borderBottom: '1px solid #333',
        textAlign: 'center',
        flexShrink: 0,
    },
    title: {
        margin: 0,
        fontSize: '1.5rem',
        color: 'var(--accent-color, #03dac6)',
    },
    status: {
        margin: '4px 0 0',
        color: 'var(--secondary-text-color, #b0b0b0)',
    },
    transcriptContainer: {
        flexGrow: 1,
        overflowY: 'auto',
        padding: '16px',
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
    },
    message: {
        padding: '10px 14px',
        borderRadius: '18px',
        maxWidth: '80%',
        wordWrap: 'break-word',
    },
    userMessage: {
        backgroundColor: 'var(--accent-color, #03dac6)',
        color: '#000',
        alignSelf: 'flex-end',
        borderBottomRightRadius: '4px',
    },
    modelMessage: {
        backgroundColor: 'var(--user-message-bg, #262626)',
        color: 'var(--primary-text-color, #e0e0e0)',
        alignSelf: 'flex-start',
        borderBottomLeftRadius: '4px',
    },
    footer: {
        padding: '24px',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        borderTop: '1px solid #333',
        flexShrink: 0,
    },
    button: {
        width: '120px',
        height: '120px',
        borderRadius: '50%',
        backgroundColor: 'var(--button-bg-color, #333333)',
        border: '4px solid #444',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        cursor: 'pointer',
        transition: 'background-color 0.2s ease, transform 0.1s ease',
        color: 'var(--button-text-color, #ffffff)',
    },
    buttonActive: {
        backgroundColor: 'var(--button-active-bg-color, #03dac6)',
        transform: 'scale(1.05)',
        border: '4px solid var(--accent-color, #03dac6)',
    },
    buttonDisabled: {
        cursor: 'not-allowed',
        opacity: 0.5,
    },
    micIcon: {
        width: '48px',
        height: '48px',
    }
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);